from django import forms
from.models import Registrationdata


class RegistrationForm(forms.Form):
    username = forms.CharField(max_length=25,
                               widget=forms.TextInput(attrs={
                                   'class': 'form-control',
                                   'placeholder': 'Username'
                               }))
    password = forms.CharField(max_length=50,
                               widget=forms.PasswordInput(attrs={
                                   'class': 'form-control',
                                   'placeholder': 'Password'
                               }))
    email = forms.CharField(max_length=50,
                            widget=forms.EmailInput(attrs={
                                'class': 'form-control',
                                'placeholder': 'Email'
                            }))
    phone = forms.CharField(max_length=15,
                            widget=forms.NumberInput(attrs={
                                'class': 'form-control',
                                'placeholder': 'Phone Number'
                            }))


class RegistrationModal(forms.ModelForm):
    username = forms.CharField(max_length=25,
                               widget=forms.TextInput(attrs={
                                   'class': 'form-control',
                                   'placeholder': 'Username'
                               }))
    password = forms.CharField(max_length=50,
                               widget=forms.PasswordInput(attrs={
                                   'class': 'form-control',
                                   'placeholder': 'Password'
                               }))
    email = forms.CharField(max_length=50,
                            widget=forms.EmailInput(attrs={
                                'class': 'form-control',
                                'placeholder': 'Email'
                            }))
    phone = forms.CharField(max_length=15,
                            widget=forms.NumberInput(attrs={
                                'class': 'form-control',
                                'placeholder': 'Phone Number'
                            }))
    class Meta:
        model= Registrationdata

        fields = [
            'username',
            'password',
            'email',
            'phone'
        ]
        # widget = {
        #     'username': forms.TextInput(attrs={
        #                         'class': 'form-control',
        #                         'placeholder': 'Username'
        #             }),
        #     'password': forms.PasswordInput(attrs={
        #                         'class': 'form-control',
        #                         'placeholder': 'Password'
        #             }),
        #     'email': forms.EmailInput(attrs={
        #                         'class': 'form-control',
        #                         'placeholder': 'Email'
        #             }),
        #     'phone': forms.NumberInput(attrs={
        #                         'class': 'form-control',
        #                         'placeholder': 'Phone Number'
        #             })
        #
        # }